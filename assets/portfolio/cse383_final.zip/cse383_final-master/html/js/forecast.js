var zipURL = "https://api.clearllc.com/api/v2/miamidb/_table/zipcode?";
var weatherURL = "https://api.openweathermap.org/data/2.5/onecall?"
var apiURL = "https://perryna4.aws.csi.miamioh.edu/final.php?"
$(document).ready(function() {
	$("#errorAlert").css("display", "none");
	$("#forecastCols").css("display", "none");
	$("#loadSpinner").css("display", "none");
});
function dismissAlert() {
	$("#errorAlert").css("display", "none");
}

function searchZip() {
		$("#loadSpinner").css("display", "");
		zip = $("#zipInput").val();
		a=$.ajax({
		url: zipURL + 'api_key=bed859b37ac6f1dd59387829a18db84c22ac99c09ee0f5fb99cb708364858818&ids=' + zip,
		method: "GET"
	}).done(function(data) {
		dismissAlert();
		getWeather(data.resource[0].latitude, data.resource[0].longitude, zip)
		
	}).fail(function(error) {
		$("#loadSpinner").css("display", "none");
		$("#forecastCols").css("display", "none");
		$("#errorAlert").css("display", "");
		$("#errorCode").text("Code: " + error.responseJSON.error.context.resource[0].code);
		$("#errorMsg").text("Message: " + error.responseJSON.error.context.resource[0].message);
	});
		return false;
	}
	
	function getWeather(lat, longi, zip) {
		a=$.ajax({
		url: weatherURL + 'appid=2d2b014eb97ec5a30ffb1b627921cd79&exclude=hourly,minutely&units=imperial&lat=' + lat + "&lon=" + longi,
		method: "GET"
		}).done(function(data) {
			$("#loadSpinner").css("display", "none");
			date1= new Date();
			$("#forecastCols").css("display", "");
			for(let i = 0; i < 7; i++) {
				tempDate = new Date(date1);
				tempDate.setDate(tempDate.getDate() + i);
				$("#day" + (i+1) +"head").text(dayOfWeek(tempDate.getDay()));
				$("#day" + (i+1) +"head2").text(getMonth(tempDate.getMonth()) + " " + tempDate.getDate());
				$("#day" + (i+1) + "low").text("Low: " + Math.round(data.daily[i].temp.min) + "\xB0F");
				$("#day" + (i+1) + "high").text("High: " + Math.round(data.daily[i].temp.max) + "\xB0F");
				$("#day" + (i+1) + "forecastdesc").text(toTitleCase(data.daily[i].weather[0].description));
				$("#day" + (i+1) + "icon").attr("src",'https://openweathermap.org/img/wn/' + data.daily[i].weather[0].icon + "@2x.png");
				b=$.ajax({
				url: apiURL + "method=setTemp&location=" + zip + "&date=" + tempDate.toISOString().slice(0, 10) +"&low=" + Math.round(data.daily[i].temp.min) + "&high=" + Math.round(data.daily[i].temp.max) + "&forecast=" + encodeURIComponent(toTitleCase(data.daily[i].weather[0].description)),
				method: "GET"
				}).done(function(data) {
				}).fail(function(error) {
				});
			}
		}).fail(function(error) {
			$("#loadSpinner").css("display", "none");
			$("#forecastCols").css("display", "none");
			$("#errorAlert").css("display", "");
			$("#errorCode").text("Code: " + error.responseJSON.error.context.resource[0].code);
			$("#errorMsg").text("Message: " + error.responseJSON.error.context.resource[0].message);
		});
		return false;
	}

function dayOfWeek(dayInt) {
	if (dayInt > 6) 
		dayInt = dayInt % 7;
	switch(dayInt) {
		case 0:
			return "Sunday";
		case 1: 
			return "Monday";
		case 2:
			return "Tuesday";
		case 3:
			return "Wednesday";
		case 4:
			return "Thursday";
		case 5:
			return "Friday";
		case 6:
			return "Saturday";
		default:
			return "INVALID DATE SPECIFIED";
	}
}
function getMonth(monthInt) {
	if (monthInt > 11) 
		monthInt = monthInt % 12;
	switch(monthInt) {
		case 0:
			return "January";
		case 1: 
			return "February";
		case 2:
			return "March";
		case 3:
			return "April";
		case 4:
			return "May";
		case 5:
			return "June";
		case 6:
			return "July";
		case 7:
			return "August";
		case 8:
			return "September";
		case 9:
			return "October";
		case 10:
			return "November";
		case 11:
			return "December";
		default:
			return "INVALID DATE SPECIFIED";
	}
}

function toTitleCase(str) {
    return str.replace(/(?:^|\s)\w/g, function(match) {
        return match.toUpperCase();
    });
}