var URL = "https://api.clearllc.com/api/v2/miamidb/_table/zipcode?";

$(document).ready(function() {
	$("#zipInfo").css("display","none");
	$("#success").css("display","none");
	$("#failure").css("display","none");
	$("#errorAlert").css("display", "none");
	$("#loadSpinner").css("display", "none");
});

function dismissAlert() {
	$("#errorAlert").css("display", "none");
}

function searchZip() {
		$("#loadSpinner").css("display", "");
		zip = $("#zipInput").val();
		a=$.ajax({
		url: URL + 'api_key=bed859b37ac6f1dd59387829a18db84c22ac99c09ee0f5fb99cb708364858818&ids=' + zip,
		method: "GET"
	}).done(function(data) {
		$("#loadSpinner").css("display", "none");
		$("#errorAlert").css("display", "none");
		$("#success").css("display", "");
		$("#stateInfo").text("State: " + data.resource[0].state);
		$("#cityInfo").text("City: " + data.resource[0].city);
		$("#timezoneInfo").text("Timezone: " + data.resource[0].timezone);
		$("#latInfo").text("Latitude: " + data.resource[0].latitude);
		$("#longInfo").text("Longitude: " + data.resource[0].longitude);
		if(data.resource[0].daylightSavingsFlag == 1) {
			$("#daylightInfo").text("Daylight Savings: YES");
		} else {
			$("#daylightInfo").text("Daylight Savings: NO");
		}
		
	}).fail(function(error) {
		$("#loadSpinner").css("display", "none");
		$("#errorAlert").css("display", "");
		$("#success").css("display", "none");
		$("#errorCode").text("Code: " + error.responseJSON.error.context.resource[0].code);
		$("#errorMsg").text("Message: " + error.responseJSON.error.context.resource[0].message);
	});
		return false;
	}