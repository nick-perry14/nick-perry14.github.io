var apiURL = "https://perryna4.aws.csi.miamioh.edu/final.php?method=getTemp&"
$(document).ready(function() {
	$("#tableHead").css("display", "none");
	$("#dateTable").css("display", "none");
	$("#zipTable").css("display", "none");
	$("#errorAlert").css("display", "none");
	$("#tablecard").css("display", "none");
});

function getHistory(){
	sort = $('input[name="sort"]:checked').val();
	date = $("#dateInput").val();
	a=$.ajax({
		url: apiURL + 'date=' + date + '&sort=' + sort,
		method: "GET"
	}).done(function(data) {
		$("#tablecard").css("display", "");
		if (sort == 1){
			$("#dateTable").css("display", "none");
			$("#zipTable").css("display", "");
			$("#tableHead").css("display", "");
			$("#tableHead").text("Requests of Forecasts on " + date +" Sorted by Zip Code");
			$('#zipTable tbody').empty();
			if (data.result.length == 0) {
				$('#zipTable > tbody:last-child').append('<tr><td colspan="5"><center>No Forecasts on Record for ' + date +'</center></td>');
			} else {
				for(var k in data.result) {
					$('#zipTable > tbody:last-child').append('<tr><td>'+ data.result[k].location +'</td><td>' + data.result[k].DateRequested + '</td><td>' + data.result[k].Low +'</td><td>' +  data.result[k].High + '</td><td>' + data.result[k].Forecast + '</td></tr>');
				}	
			}
	} else {
			$("#dateTable").css("display", "");
			$("#zipTable").css("display", "none");
			$("#tableHead").css("display", "");
			$("#tableHead").text("Requests of Forecasts on " + date +" Sorted by Time of Request");
			$('#dateTable tbody').empty();
			if (data.result.length == 0) {
				$('#dateTable > tbody:last-child').append('<tr><td colspan="5"><center>No Forecasts on Record for ' + date +'</center></td>');
			} else {
				for(var k in data.result) {
					$('#dateTable > tbody:last-child').append('<tr><td>'+ data.result[k].DateRequested +'</td><td>' + data.result[k].location + '</td><td>' + data.result[k].Low +'</td><td>' +  data.result[k].High + '</td><td>' + data.result[k].Forecast + '</td></tr>');
				}
			}
		}
	}).fail(function(error) {
		$("#errorAlert").css("display", "");
		$("#dateHead").css("display", "none");
		$("#dateTable").css("display", "none");
		$("#zipHead").css("display", "none");
		$("#zipTable").css("display", "none");
	});
		return false;
	
}