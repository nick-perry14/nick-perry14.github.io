url('https://logic.puzzlebaron.com/pdf/O685VY.pdf').
solution([['8500', 'Gilda Gray', 'Teacher', 'Daly City'], ['9000', 'Fred Francis', 'Lawyer', 'Olema'], ['9500', 'Ed Ewing', 'Academic', 'Redway'], ['10000', 'Bev Baird', 'Rancher', 'Mountain Mesa'], ['10500', 'Cate Carlson', 'Doctor', 'Lakota'], ['11000', 'Jed Jarvis', 'Architect', 'Unionville']]).
 
solve(T) :-
    T=[['8500', C1, P1, H1], ['9000', C2, P2, H2], ['9500', C3, P3, H3], ['10000', C4, P4, H4], ['10500', C5, P5, H5], ['11000', C6, P6, H6]],
    clue3(T),
    clue7(T),
    clue8(T),
    permutation([C1, C2, C3, C4, C5, C6],
                
                [ 'Bev Baird',
                  'Cate Carlson',
                  'Ed Ewing',
                  'Fred Francis',
                  'Gilda Gray',
                  'Jed Jarvis'
                ]),
    permutation(
                [ P1,
                  P2,
                  P3,
                  P4,
                  P5,
                  P6
                ],
                ['Academic', 'Architect', 'Doctor', 'Lawyer', 'Rancher', 'Teacher']),
    permutation(
                [ H1,
                  H2,
                  H3,
                  H4,
                  H5,
                  H6
                ],
                
                [ 'Daly City',
                  'Lakota',
                  'Mountain Mesa',
                  'Olema',
                  'Redway',
                  'Unionville'
                ]),
    
    clue1(T),
    clue10(T),
    clue12(T),
    clue4(T),
    clue2(T),
    clue6(T),
    clue9(T),
    clue11(T),
    clue5(T),
    true.
 
clue1(T) :-
    member([VC1, _, 'Academic', _], T),
    member([VC2, _, _, 'Mountain Mesa'], T),
    atom_number(VC2, VC21),
    atom_number(VC1, VC11),
    VC21-500=:=VC11.
 
clue2(T) :-
    member([VC1, 'Ed Ewing', _, _], T),
    member([VC2, _, 'Teacher', _], T),
    atom_number(VC1, VC11),
    atom_number(VC2, VC21),
    VC11-1000=:=VC21.
 
clue3(T) :-
    member([VC1, 'Gilda Gray', _, H1], T),
    member([VC2, 'Bev Baird', _, H2], T),
    (   VC1='8500',
        H1=_,
        VC2=_,
        H2='Mountain Mesa'
    ;   VC1=_,
        H1='Mountain Mesa',
        VC2='8500',
        H2=_
    ).
 
clue4(T) :-
    member([VC1, 'Ed Ewing', _, _], T),
    member([VC2, _, _, 'Lakota'], T),
    atom_number(VC1, VC11),
    atom_number(VC2, VC21),
    VC11<VC21.
 
clue5(T) :-
    not(member(['10500', 'Jed Jarvis', _, _], T)).
 
clue6(T) :-
    member([VC1, _, _, 'Redway'], T),
    member([VC2, _, 'Lawyer', _], T),
    atom_number(VC1, VC11),
    atom_number(VC2, VC21),
    VC11>VC21.
 
clue7(T) :-
    member(['9500', PA1, _, HA1], T),
    member([VC1, PA2, 'Architect', HA2], T),
    VC1\='9500',
    (   PA1='Jed Jarvis',
        HA1=_,
        PA2=_,
        HA2='Redway'
    ;   PA1=_,
        HA1='Redway',
        PA2='Jed Jarvis',
        HA2=_
    ).
 
clue8(T) :-
    member([VC1, _, JA1, 'Lakota'], T),
    member(['9000', _, JA2, _], T),
    VC1\='9000',
    (   JA1='Doctor',
        JA2='Lawyer'
    ;   JA1='Lawyer',
        JA2='Doctor'
    ).
 
clue9(T) :-
    member([VC1, _, 'Rancher', _], T),
    member([VC2, _, _, 'Unionville'], T),
    atom_number(VC1, VC11),
    atom_number(VC2, VC21),
    VC11<VC21.
 
clue10(T) :-
    member([VC1, 'Gilda Gray', _, _], T),
    member([VC2, _, _, 'Olema'], T),
    atom_number(VC2, VC21),
    atom_number(VC1, VC11),
    VC21-500=:=VC11.
 
 
clue11(T) :-
    member([VC1, 'Fred Francis', _, _], T),
    VC1\='10500'.
 
clue12(T) :-
    member([VC1, 'Gilda Gray', _, _], T),
    member([VC2, _, 'Academic', _], T),
    atom_number(VC1, VC11),
    atom_number(VC2, VC21),
    VC21-1000=:=VC11.

check :- 
	% Confirm that the correct solution is found
	solution(S), (solve(S); not(solve(S)), writeln("Fails Part 1: Does  not eliminate the correct solution"), fail),
	% Make sure S is the ONLY solution 
	not((solve(T), T\=S, writeln("Failed Part 2: Does not eliminate:"), print_table(T))),
	writeln("Found 1 solutions").

print_table([]).
print_table([H|T]) :- atom(H), format("~|~w~t~20+", H), print_table(T). 
print_table([H|T]) :- is_list(H), print_table(H), nl, print_table(T). 


% Show the time it takes to conform that there are no incorrect solutions
checktime :- time((not((solution(S), solve(T), T\=S)))).
