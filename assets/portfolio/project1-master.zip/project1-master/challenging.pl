%% I will not accept a submission with the T0D0 comments left in place!

url("https://logic.puzzlebaron.com/pdf/X896BU.pdf").

solution([
         ['50 Riders', 'Victor', 'Green', 'Loop-D-Loop'],
         ['75 Riders', 'Darrell', 'Blue', 'Agony Alley'],
         ['100 Riders', 'Guy', 'Orange', 'Speed Demon'],
         ['125 Riders', 'Marc', 'Red', 'The Screamer'],
         ['150 Riders', 'Sergio', 'Purple', 'Zinjo']
         ]).

solve(T) :- T = [
        ['50 Riders', E1, S1, R1],
        ['75 Riders', E2, S2, R2],
        ['100 Riders', E3, S3, R3],
        ['125 Riders', E4, S4, R4],
        ['150 Riders', E5, S5, R5]
        ],
    permutation([E1, E2, E3, E4, E5], ['Darrell', 'Guy', 'Marc', 'Sergio', 'Victor']),
    permutation([S1, S2, S3, S4, S5], ['Blue', 'Green', 'Orange', 'Purple', 'Red']),
    permutation([R1, R2, R3, R4, R5], ['Agony Alley', 'Loop-D-Loop', 'The Screamer', 'Speed Demon', 'Zinjo']),
    clue1(T),
    clue2(T),
    clue3(T),
    clue4(T),
    clue5(T),
    clue6(T),
    clue7(T),
    clue8(T),
    clue9(T),
    clue10(T),
    true.
        
clue1(T) :- 
    member([_, 'Victor', _, 'Loop-D-Loop'], T);
    member([_, 'Victor', 'Purple', _], T).
clue2(T) :- not(member([_, 'Marc', 'Orange', _], T)).
clue3(T) :- (member(['75 Riders', _, _, 'The Screamer'], T), member(['50 Riders', _, 'Orange', _], T)); (member(['100 Riders', _, _, 'The Screamer'], T), member(['75 Riders', _, 'Orange', _], T)); (member(['125 Riders', _, _, 'The Screamer'], T), member(['100 Riders', _, 'Orange', _], T)); (member(['150 Riders', _, _, 'The Screamer'], T), member(['125 Riders', _, 'Orange', _], T)).
clue4(T) :- member(['50 Riders', _, 'Green', _], T).
clue5(T) :- member(['50 Riders', EA1, CA1, _], T), member([_, EA2, CA2, 'Agony Alley'], T), ((EA1 = 'Victor', CA1 = _, EA2 = _, CA2='Blue'); (EA1=_, CA1='Blue', EA2='Victor', CA2=_)).
clue6(T) :- (member(['50 Riders', 'Darrell', _, _], T), member(['75 Riders', _, 'Orange', _], T));(member(['75 Riders', 'Darrell', _, _], T), member(['100 Riders', _, 'Orange', _], T)); (member(['100 Riders', 'Darrell', _, _], T), member(['125 Riders', _, 'Orange', _], T)); (member(['125 Riders', 'Darrell', _, _], T), member(['150 Riders', _, 'Orange', _], T)).
clue7(T) :-  not(member(['150 Riders', _, _, 'Speed Demon'], T)).
clue8(T) :- not(member([_, 'Marc', _, 'Zinjo'], T)).
clue9(T) :- not(member([_, 'Guy', 'Purple', _], T)).
clue10(T) :- (member(['25 Riders', _, _, 'The Screamer'], T), member(['50 Riders', _, 'Purple', _], T)); (member(['50 Riders', _, _, 'The Screamer'], T), member(['75 Riders', _, 'Purple', _], T)); (member(['75 Riders', _, _, 'The Screamer'], T), member(['100 Riders', _, 'Purple', _], T)); (member(['100 Riders', _, _, 'The Screamer'], T), member(['125 Riders', _, 'Purple', _], T)); (member(['125 Riders', _, _, 'The Screamer'], T), member(['150 Riders', _, 'Purple', _], T)).


check :- 
	% Confirm that the correct solution is found
	solution(S), (solve(S); not(solve(S)), writeln("Fails Part 1: Does  not eliminate the correct solution"), fail),
	% Make sure S is the ONLY solution 
	not((solve(T), T\=S, writeln("Failed Part 2: Does not eliminate:"), print_table(T))),
	writeln("Found 1 solutions").

print_table([]).
print_table([H|T]) :- atom(H), format("~|~w~t~20+", H), print_table(T). 
print_table([H|T]) :- is_list(H), print_table(H), nl, print_table(T). 


% Show the time it takes to conform that there are no incorrect solutions
checktime :- time((not((solution(S), solve(T), T\=S)))).
