// Copyright 2021 Nick Perry 
/* 
 * A very lightweight (light as air) implementation of a simple CSV-based 
 * database system that uses SQL-like syntax for querying and updating the
 * CSV files.
 * 
 */

#include <string>
#include <fstream>
#include <tuple>
#include <algorithm>
#include "SQLAir.h"
#include <sstream>
#include "HTTPFile.h"

/**
 * A fixed HTTP response header that is used by the runServer method below.
 * Note that this a constant (and not a global variable)
 */
const std::string HTTPRespHeader = "HTTP/1.1 200 OK\r\n"
    "Server: localhost\r\n"
    "Connection: Close\r\n"
    "Content-Type: text/plain\r\n"
    "Content-Length: ";

// Model Prototype (not neccessary for these methods to be OBJECT ORIENTED.)
void urlToCSV(CSV& csv, const std::string& fileOrURL);

// API method to perform operations associated with a "select" statement
// to print columns that match an optional condition.
void SQLAir::selectQuery(CSV& csv, bool mustWait, StrVec colNames, 
        const int whereColIdx, const std::string& cond, 
        const std::string& value, std::ostream& os) {
    int counter = 0;
    // Convert any "*" to suitable column names. See CSV::getColumnNames()
    this->checkWildcard(csv, colNames);
    // First print the column names.
    os << colNames << std::endl;
    // Print each row that matches an optional condition.
    for (const auto& row : csv) {
        // Determine if this row matches "where" clause condition, if any
        // see SQLAirBase::matches() helper method.
        if (whereColIdx == -1 || SQLAirBase::matches(
                row.at(whereColIdx), cond, value)) {
        std::string delim = "";
        for (const auto& colName : colNames) {
            os << delim << row.at(csv.getColumnIndex(colName));
            delim = "\t";
        }
        os << std::endl;
        counter++;
    }
    }
    os << counter << " row(s) selected." << std::endl;
}

void
SQLAir::updateQuery(CSV& csv,  bool mustWait, StrVec colNames, StrVec values, 
        const int whereColIdx, const std::string& cond, 
        const std::string& value, std::ostream& os)  {
    // Update each row that matches an optional condition.
    throw Exp("update is not yet implemented.");
}


void 
SQLAir::insertQuery(CSV& csv, bool mustWait, StrVec colNames, 
        StrVec values, std::ostream& os) {
    throw Exp("insert is not yet implemented.");
}

void 
SQLAir::deleteQuery(CSV& csv, bool mustWait, const int whereColIdx, 
        const std::string& cond, const std::string& value, std::ostream& os) {
    throw Exp("delete is not yet implemented.");
}

void 
SQLAir::httpQuery(std::ostream& os, const std::string& query) {
    std::ostringstream strings("");
    try {
      this->process(query, strings);
    } catch(const std::exception &exp) {
        strings << "Error: "<< exp.what() << std::endl;
    }
    os << HTTPRespHeader << strings.str().length() << "\r\n\r\n" 
            << strings.str();    
}

void 
SQLAir::serveClient(std::istream& is, std::ostream& os) {
    std::string line;
    std::getline(is, line);
    std::string decoded = Helper::url_decode(line);
    for (std::string hdr; std::getline(is, hdr) &&
            !hdr.empty() && hdr != "\r";) {}
    if (decoded.substr(4, 15) == "/sql-air?query=") {
        std::string query = decoded.substr(19, decoded.find(" HTTP/1.1") - 19);
        this->httpQuery(os, query);
    } else {
    os << http::file(decoded.substr(5, decoded.find(" HTTP/1.1") - 5));
    }
}

// The method to have this class run as a web-server. 
void 
SQLAir::runServer(boost::asio::ip::tcp::acceptor& server, const int maxThr) {
        using namespace boost::asio;
        using namespace boost::asio::ip;   
        while (true) {
        // Wait for a client to connect.
        TcpStreamPtr client = std::make_shared<tcp::iostream>();
        // The following method calls waits (could wait forever) until
        // a client connects.
        server.accept(*client->rdbuf());
        // Have helper method process the client connection.
        // Max thread checker -- Implemented early.  
        while (numThreads >= maxThr) {}
        std::thread thr([this, client](){ serveClient(*client, *client); });
        thr.detach();
    }
}

CSV& SQLAir::loadAndGet(std::string fileOrURL) {
    // Check if the specified fileOrURL is already loaded in a thread-safe
    // manner to avoid race conditions on the unordered_map
    {
        std::lock_guard<std::mutex> guard(recentCSVMutex);
        // Use recent CSV if parameter was empty string.
        fileOrURL = (fileOrURL.empty() ? recentCSV : fileOrURL);
        // Update the most recently used CSV for the next round
        recentCSV = fileOrURL;
        if (inMemoryCSV.find(fileOrURL) != inMemoryCSV.end()) {
            // Requested CSV is already in memory. Just return it.
            return inMemoryCSV.at(fileOrURL);
        }
    }
    // When control drops here, we need to load the CSV into memory.
    // Loading or I/O is being done outside critical sections
    CSV csv;   // Load data into this csv
    if (fileOrURL.find("http://") == 0) {
        urlToCSV(csv, fileOrURL);
    } else {
        // We assume it is a local file on the server. Load that file.
        std::ifstream data(fileOrURL);
        // This method may throw exceptions on errors.
        csv.load(data);
    }
    // We get to this line of code only if the above if-else to load the
    // CSV did not throw any exceptions. In this case we have a valid CSV
    // to add to our inMemoryCSV list. We need to do that in a thread-safe
    // manner.
    std::lock_guard<std::mutex> guard(recentCSVMutex);
    // Move (instead of copy) the CSV data into our in-memory CSVs
    inMemoryCSV[fileOrURL].move(csv);
    // Return a reference to the in-memory CSV (not temporary one)
    return inMemoryCSV.at(fileOrURL);
}

// Save the currently loaded CSV file to a local file.
void 
SQLAir::saveQuery(std::ostream& os) {
    if (recentCSV.empty() || recentCSV.find("http://") == 0) {
        throw Exp("Saving CSV to an URL using POST is not implemented");
    }
    // Create a local file and have the CSV write itself.
    std::ofstream csvData(recentCSV);
    inMemoryCSV.at(recentCSV).save(csvData);
    os << recentCSV << " saved.\n";
}

void SQLAir::checkWildcard(const CSV& csv, StrVec& colNames) {
    for (const auto& col : colNames) {
        if (col == "*") {
            colNames.clear();
            for (const auto& newCol : csv.getColumnNames())  {
                colNames.push_back(newCol);
            }
            return;
        }
    }
}

void urlToCSV(CSV& csv, const std::string& fileOrURL) {
        // This is an URL. We have to get the stream from a web-server
        // Implement this feature.
        std::string host, port, path;
        std::tie(host, port, path) = Helper::breakDownURL(fileOrURL);
           boost::asio::ip::tcp::iostream data(host, port);
            data << "GET "   << path     << " HTTP/1.1\r\n"
               << "Host: " << host << "\r\n"
               << "Connection: Close\r\n\r\n";
            if (!data.good()) {
                throw Exp("Unable to connect to " + host + " at port " + port);
            }
            std::string status;
            std::getline(data, status);
            status = Helper::trim(status);
        for (std::string hdr; std::getline(data, hdr) &&
            !hdr.empty() && hdr != "\r";) {}
        if (status == "HTTP/1.1 200 OK") {
            csv.load(data); 
        } else {
            throw Exp("Error (" + status + ") getting " + path +  " from " +
                    host + " at port " + port);
        }
}
