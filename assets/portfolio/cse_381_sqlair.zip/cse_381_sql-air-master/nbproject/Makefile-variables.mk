#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
CND_BUILDDIR=build
CND_DISTDIR=dist
# Debug configuration
CND_PLATFORM_Debug=GNU-Linux
CND_ARTIFACT_DIR_Debug=
CND_ARTIFACT_NAME_Debug=cse_381_sql-air
CND_ARTIFACT_PATH_Debug=cse_381_sql-air
CND_PACKAGE_DIR_Debug=dist/Debug/GNU-Linux/package
CND_PACKAGE_NAME_Debug=cse381sql-air.tar
CND_PACKAGE_PATH_Debug=dist/Debug/GNU-Linux/package/cse381sql-air.tar
# Release configuration
CND_PLATFORM_Release=GNU-Linux
CND_ARTIFACT_DIR_Release=
CND_ARTIFACT_NAME_Release=cse_381_sql-air_opt
CND_ARTIFACT_PATH_Release=cse_381_sql-air_opt
CND_PACKAGE_DIR_Release=dist/Release/GNU-Linux/package
CND_PACKAGE_NAME_Release=cse381sql-air.tar
CND_PACKAGE_PATH_Release=dist/Release/GNU-Linux/package/cse381sql-air.tar
#
# include compiler specific variables
#
# dmake command
ROOT:sh = test -f nbproject/private/Makefile-variables.mk || \
	(mkdir -p nbproject/private && touch nbproject/private/Makefile-variables.mk)
#
# gmake command
.PHONY: $(shell test -f nbproject/private/Makefile-variables.mk || (mkdir -p nbproject/private && touch nbproject/private/Makefile-variables.mk))
#
include nbproject/private/Makefile-variables.mk
